'''
Description: 论文1审意见后添加获取每个bugid对应的comments,使用restful API方式获取 for android
version: 1.0
Company: ie
Author: Roy Xu
Date: 2020-11-20 21:39:30
LastEditors: Roy Xu
LastEditTime: 2020-11-23 21:31:53
'''

import requests
import jsonpath
import pandas as pd
import time


def stampToTime(stamp):  # 时间转换
    datatime = time.strftime("%Y-%m-%d %H:%M:%S",
                             time.localtime(float(str(stamp)[0:10])))
    datatime = datatime + '.' + str(stamp)[10:]
    return datatime


def get_json(url):
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            json_text = response.json()
            return json_text
    except Exception:
        print('此页有问题！')
        return None


def resolvejson(url, id):
    data = []
    doc = get_json(url)  # 返回包含comments的json串
    # print(doc)
    jobs = doc['bugs'][id]['comments']  # 获取comments子节点json值
    m = len(jobs)  # comments子节点的个数
    # print(m)
    for i in range(0, m):
        dic = {}
        # 从comments节点开始，匹配content节点
        print('-----'+str(i)+'-------')
        dic['bug_id'] = jsonpath.jsonpath(jobs, '$..bug_id')[i]  # bug_id
        dic['id'] = jsonpath.jsonpath(jobs, '$..id')[i]  # userid
        dic['creation_time'] = jsonpath.jsonpath(
            jobs, '$..creation_time')[i]  # creation_time
        dic['raw_text'] = jsonpath.jsonpath(jobs, '$..raw_text')[i]
        dic['tags'] = jsonpath.jsonpath(jobs, '$..tags')[i]
        dic['is_private'] = jsonpath.jsonpath(jobs, '$..is_private')[i]
        dic['time'] = jsonpath.jsonpath(jobs, '$..time')[i]
        dic['author'] = jsonpath.jsonpath(jobs, '$..author')[i]
        dic['creator'] = jsonpath.jsonpath(jobs, '$..creator')[i]
        dic['attachment_id'] = jsonpath.jsonpath(jobs, '$..attachment_id')[i]
        dic['count'] = jsonpath.jsonpath(jobs, '$..count')[i]
        dic['text'] = jsonpath.jsonpath(jobs, '$..text')[i]
        # print(dic)
        data.append(dic)
    return data
    # print(pd.DataFrame(data))
    # pd.DataFrame(data).to_csv('buginfo.csv',mode='a',header=False)
    # return pd.DataFrame(data)


'''
@description: 读取baseinfo_n.txt中的id,拼接成获取地址:https://bugzilla.mozilla.org/rest/bug/35?include_fields=summary,status,resolution
爬取对应的bugid的JSON数据,并存储
@param {type}
@return:
'''


def getComments():
    for i in range(10, 11):
        sourcefile = "../bugdata/android/comments/source/bugid_android_18_19_" + \
            str(i) + ".txt"
        # targetfile = "../bugdata/desktop/comments/firefoxcomments_" + \
        #     str(i) + ".csv"
        # https://bugzilla.mozilla.org/rest/bug/1636466/comment
        k = 0
        for bugid in open(sourcefile, encoding="utf8"):
            bugid = bugid[:-1]
            targetfile = "../bugdata/android/comments/target/androidcomments_" + \
                str(i)+'_'+str(bugid) + ".csv"
            k += 1
            id = bugid
            # id = '1636466'
            print('正在获取'+id+'的comments数据,它是第'+str(k)+'条记录!')
            bugurl = "https://bugzilla.mozilla.org/rest/bug/" + id + "/comment"
            d = resolvejson(bugurl, id)
            # print(pd.DataFrame(d))
            pd.DataFrame(d).to_csv(targetfile, mode='a', header=False, index=0)


'''
@description: main函数,设置header
@param {type}
@return:
'''
if __name__ == '__main__':
    parent = []
    headers = {
        'cookie':
        'lastCity=101010100; JSESSIONID=""; __g=-; _uab_collina=155269833969139683439973; __c=1552698410; '
        '__l=r=https%3A%2F%2Fwww.zhipin.com%2F&l=%2Fwww.zhipin.com%2Fjob_detail%2F%3Fquery%3D%25E5%25A4%25A7'
        '%25E6%2595%25B0%25E6 '
        '%258D%25AE%26city%3D101010100%26industry%3D%26position%3D; '
        'Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1552698340, '
        '1552698711; __a=34449685.1552698337.1552698337.1552698410.7.2.6.7; '
        'Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1552698721',
        'accept-encoding':
        'gzip, deflate, br',
        'accept-language':
        'zh-CN,zh;q=0.9',
        'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 '
        'Safari/537.36',
        'accept':
        'application/json, text/javascript, */*; q=0.01',
        'referedr':
        'https://www.zhipin.com/job_detail/?query=%E5%A4%A7%E6%95%B0%E6%8D%AE&city=101010100&industry=&position=',
        'authority':
        'www.zhipin.com',
        'x-requested-with':
        'XMLHttpRequest',
    }
    # 此处各个函数的调用是分步的,完成一个环节做下一步,没有自动执行,是手动控制
    # 获取基本bugid的地址存于baseinfo_n.txt文件
    # spiderChildren()
    # 获取基本bugid的详细信息
    getComments()
