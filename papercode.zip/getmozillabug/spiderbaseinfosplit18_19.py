
'''
@Author: Roy Xu
@Date: 2020-06-19 22:58:14
LastEditTime: 2020-08-05 14:44:16
LastEditors: Roy Xu
@Description:读取text_n.txt中的各个component下所有的solution状态的组合地址,爬取所有的bugs地址,
存放到baseinfo_n.txt,再调用getbugs函数获取详细的bug.
@FilePath: \getmozillabug\Spidersplit.py
'''
# @Author  : Roy Xu

import requests
import jsonpath
import pandas as pd
import time


def stampToTime(stamp):  # 时间转换
    datatime = time.strftime("%Y-%m-%d %H:%M:%S",
                             time.localtime(float(str(stamp)[0:10])))
    datatime = datatime + '.' + str(stamp)[10:]
    return datatime


def get_json(url):
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            json_text = response.json()
            return json_text
    except Exception:
        print('此页有问题！')
        return None


def resolvejson(url):
    data = []
    doc = get_json(url)
    jobs = doc['bugs']
    for job in jobs:
        dic = {}
        # 从根节点开始，匹配content节点
        dic['id'] = jsonpath.jsonpath(job, '$..id')[0]  # bugid
        dic['product'] = jsonpath.jsonpath(job, '$..product')[0]
        dic['creation_time'] = jsonpath.jsonpath(job, '$..creation_time')[0]
        dic['component'] = jsonpath.jsonpath(job, '$..component')[0]
        dic['priority'] = jsonpath.jsonpath(job, '$..priority')[0]
        dic['severity'] = jsonpath.jsonpath(job, '$..severity')[0]
        dic['creator'] = jsonpath.jsonpath(job, '$..creator')[0]
        dic['real_name'] = jsonpath.jsonpath(job['creator_detail'],
                                             '$..real_name')[0]
        dic['email'] = jsonpath.jsonpath(job['creator_detail'], '$..email')[0]
        dic['creatorid'] = jsonpath.jsonpath(job['creator_detail'], '$..id')[0]
        dic['type'] = jsonpath.jsonpath(job, '$..type')[0]
        dic['status'] = jsonpath.jsonpath(job, '$..status')[0]
        dic['resolution'] = jsonpath.jsonpath(job, '$..resolution')[0]
        dic['assigned_to'] = jsonpath.jsonpath(job, '$..assigned_to')[0]
        dic['assigned_userid'] = jsonpath.jsonpath(
            job['assigned_to_detail'], '$..id')[0]
        dic['assigned_real_name'] = jsonpath.jsonpath(
            job['assigned_to_detail'], '$..real_name')[0]
        dic['assigned_nick'] = jsonpath.jsonpath(
            job['assigned_to_detail'], '$..nick')[0]
        dic['assigned_name'] = jsonpath.jsonpath(
            job['assigned_to_detail'], '$..name')[0]
        dic['assigned_email'] = jsonpath.jsonpath(
            job['assigned_to_detail'], '$..email')[0]
        data.append(dic)
    return data
    # print(pd.DataFrame(data))
    # pd.DataFrame(data).to_csv('buginfo.csv',mode='a',header=False)
    # return pd.DataFrame(data)


'''
@description: 读取baseinfo_n.txt中的id,拼接成获取地址:https://bugzilla.mozilla.org/rest/bug/35?include_fields=summary,status,resolution
爬取对应的bugid的JSON数据,并存储
@param {type} 
@return: 
'''


def getbugs():
    for i in range(0, 39):
        sourcefile = "../bugdata/split/baseinfo/18_19/baseinfo_18_19_" + \
            str(i) + ".txt"
        targetfile = "../bugdata/split/baseinfo/18_19/buginfo_18_19_" + \
            str(i) + ".csv"
        # https://bugzilla.mozilla.org/rest/bug/1636466
        # https://bugzilla.mozilla.org/rest/bug/1636466?include_fields=product,component,id,creator,creation_time,priority,severity,type,status,resolution,assigned_to_detail
        includefield = "include_fields=product,component,id,creator,creation_time,priority,severity,type,status,resolution,assigned_to"
        k = 0
        for bugid in open(sourcefile, encoding="utf8"):
            k += 1
            id = bugid[:-1]
            print('正在获取'+id+'的baseinfo数据,它是第'+str(k)+'条记录!')
            bugurl = "https://bugzilla.mozilla.org/rest/bug/" + id + "?" + includefield
            d = resolvejson(bugurl)
            # print(pd.DataFrame(d))
            pd.DataFrame(d).to_csv(targetfile, mode='a', header=False, index=0)


'''
@description: main函数,设置header
@param {type} 
@return: 
'''
if __name__ == '__main__':
    parent = []
    headers = {
        'cookie':
        'lastCity=101010100; JSESSIONID=""; __g=-; _uab_collina=155269833969139683439973; __c=1552698410; '
        '__l=r=https%3A%2F%2Fwww.zhipin.com%2F&l=%2Fwww.zhipin.com%2Fjob_detail%2F%3Fquery%3D%25E5%25A4%25A7'
        '%25E6%2595%25B0%25E6 '
        '%258D%25AE%26city%3D101010100%26industry%3D%26position%3D; '
        'Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1552698340, '
        '1552698711; __a=34449685.1552698337.1552698337.1552698410.7.2.6.7; '
        'Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1552698721',
        'accept-encoding':
        'gzip, deflate, br',
        'accept-language':
        'zh-CN,zh;q=0.9',
        'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 '
        'Safari/537.36',
        'accept':
        'application/json, text/javascript, */*; q=0.01',
        'referedr':
        'https://www.zhipin.com/job_detail/?query=%E5%A4%A7%E6%95%B0%E6%8D%AE&city=101010100&industry=&position=',
        'authority':
        'www.zhipin.com',
        'x-requested-with':
        'XMLHttpRequest',
    }
    # 此处各个函数的调用是分步的,完成一个环节做下一步,没有自动执行,是手动控制
    # 获取基本bugid的地址存于baseinfo_n.txt文件
    # spiderChildren()
    # 获取基本bugid的详细信息
    getbugs()
