
'''
@Author: Roy Xu
@Date: 2020-06-19 22:58:14
LastEditTime: 2020-08-12 17:09:37
LastEditors: Roy Xu
@Description:读取text_n.txt中的各个component下所有的solution状态的组合地址,爬取所有的bugs地址,
存放到baseinfo_n.txt,再调用getbugs函数获取详细的bug.这是项目执行的第四个文件
@FilePath: \getmozillabug\Spidersplit.py
'''
# @Author  : Roy Xu


import pandas as pd


'''
@Description: 从/split/history目录baseinfo_18_19.txt获取bugid,获取history页面的table信息,
并转存至csv文件中,一个id对应一个csv文件,完全结束以后,通过 copy *.csv merage.csv 指令合并成一个文件
@Author: Roy Xu
@Date: 2020-07-31 10:37:15
@param {type}
@return:
'''


def get_history():
    # tb = pd.read_html(url)[0].T
    sourcefile = "../bugdata/android/history/bugid_18_19_fixed.txt"
    # targetfile = "./split/history/bughistory_" + str(i) + ".csv"
    # https://bugzilla.mozilla.org/rest/bug/1429672/history
    # https://bugzilla.mozilla.org/show_activity.cgi?id=1429672
    k = 0
    for bugid in open(sourcefile):
        k += 1
        id = bugid[:-1]
        # id = '1427533'
        bugurl = "https://bugzilla.mozilla.org/show_activity.cgi?id=" + id
        print('正在获取'+id+'的history,它是第'+str(k)+'条记录!')
        tb = pd.read_html(bugurl)[0]
        targetfile = '../bugdata/android/history/bugid_18_19_fixed_'+id+'.csv'
        tb.to_csv(targetfile, mode='w', header=0, index=0)
        # print(tb)
        da = pd.read_csv(targetfile)
        da[id] = id
        # print(da)
        print('正在添加'+id+'的history的bugid,它是第'+str(k)+'条记录!')
        da.to_csv(targetfile, mode='w', header=1, index=0)
        # print(da)


def history():
    id = '1605945'
    bugurl = "https://bugzilla.mozilla.org/show_activity.cgi?id=" + id
    tb = pd.read_html(bugurl)[0]
    print(tb)
    tb.to_csv('../bugdata/android/history/bugid_18_19_fixed_'+id+'.csv',
              mode='w', header=0, index=0)


'''
@Description: 此函数为临时使用,get_history函数获取时漏加bugid字段,此为补救,正常应放到
get_history中实现
@Author: Roy Xu
@Date: 2020-07-31 22:31:08
@param {type}
@return:
'''


def addcolumn():
    sourcefile = "../bugdata/android/history/bugid_18_19_fixed.txt"
    # targetfile = "./split/history/bughistory_" + str(i) + ".csv"
    # https://bugzilla.mozilla.org/rest/bug/1429672/history
    # https://bugzilla.mozilla.org/show_activity.cgi?id=1429672
    k = 0
    for bugid in open(sourcefile):
        k += 1
        id = bugid[:-1]
        id = '1605945'
        da = pd.read_csv(
            '../bugdata/android/history/bugid_18_19_fixed_'+id+'.csv')
        da[id] = id
        print('正在添加'+id+'的history的bugid,它是第'+str(k)+'条记录!')
        da.to_csv('../bugdata/android/history/bugid_18_19_fixed_'+id+'.csv',
                  mode='w', header=1, index=0)
# head=0会使第一行数据丢失


'''
@description: main函数,设置header
@param {type}
@return:
'''
if __name__ == '__main__':
    parent = []
    headers = {
        'cookie':
        'lastCity=101010100; JSESSIONID=""; __g=-; _uab_collina=155269833969139683439973; __c=1552698410; '
        '__l=r=https%3A%2F%2Fwww.zhipin.com%2F&l=%2Fwww.zhipin.com%2Fjob_detail%2F%3Fquery%3D%25E5%25A4%25A7'
        '%25E6%2595%25B0%25E6 '
        '%258D%25AE%26city%3D101010100%26industry%3D%26position%3D; '
        'Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1552698340, '
        '1552698711; __a=34449685.1552698337.1552698337.1552698410.7.2.6.7; '
        'Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1552698721',
        'accept-encoding':
        'gzip, deflate, br',
        'accept-language':
        'zh-CN,zh;q=0.9',
        'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 '
        'Safari/537.36',
        'accept':
        'application/json, text/javascript, */*; q=0.01',
        'referedr':
        'https://www.zhipin.com/job_detail/?query=%E5%A4%A7%E6%95%B0%E6%8D%AE&city=101010100&industry=&position=',
        'authority':
        'www.zhipin.com',
        'x-requested-with':
        'XMLHttpRequest',
    }
    # 此处各个函数的调用是分步的,完成一个环节做下一步,没有自动执行,是手动控制
    # 获取基本bugid的地址存于baseinfo_n.txt文件
    # spiderChildren()
    # 获取基本bugid的详细信息
    # 获取bugid的history
    # getbughistory()
    # get_history()

    history()  # 测试
    addcolumn()
