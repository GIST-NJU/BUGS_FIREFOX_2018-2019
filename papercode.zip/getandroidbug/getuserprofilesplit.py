'''
@Description:此程序是根据userid.txt文件获取所有用户的profile信息,txt的文件被分割成若干小文件机型分别获取,
最后拼接成完整文件,这是项目执行的第三个文件
@version: 1.0
@Company: ie
@Author: Roy Xu
@Date: 2020-07-23 15:10:39
LastEditors: Roy Xu
LastEditTime: 2020-08-11 11:48:22
'''

import pandas as pd
import csv
import os

rows = []
# sourcefile = "../bugdata/android/profile/userid_"
# targetfile = "../bugdata/android/profile/userprofile_"
sourcefile = "../bugdata/android/profile/assignedto/assignedtouserid_"
targetfile = "../bugdata/android/profile/assignedto/assignedtouserprofile_"


def getProfile(url, id):
    # tb = pd.read_html(url)[0].Tr
    tb = pd.read_html(url)[0]
    tb.to_csv(
        tf, mode='w', header=0)
    csvFile = open(
        tf, "r", encoding='utf-8')
    reader = csv.reader(csvFile)
    # rows.append(['userid', 'permissions', 'reviewrequests', 'feedbackrequests', 'needinforequests', 'bugsfiled',
    #              'commentsmade', 'assignedto', 'commentedon', 'qacontact', 'patchessubmitted', 'patchesreviewed', 'bugspoked'])
    # print(rows)
    userid = id
    permissions = 0
    reviewrequests = 0
    feedbackrequests = 0
    needinforequests = 0
    bugsfiled = 0
    commentsmade = 0
    assignedto = 0
    commentedon = 0
    qacontact = 0
    patchessubmitted = 0
    patchesreviewed = 0
    bugspoked = 0
    for item in reader:
        # print(item)
        if item[2] == 'Permissions':
            permissions = item[3]
            # print(permissions)
        elif item[2] == 'Review requests':
            reviewrequests = item[3]
            # print(reviewrequests)
        elif item[2] == 'Feedback requests':
            feedbackrequests = item[3]
            # print(feedbackrequests)
        elif item[2] == 'Needinfo requests':
            needinforequests = item[3]
            # print(needinforequests)
        elif item[2] == 'Bugs filed':
            bugsfiled = item[3]
            # print(bugsfiled)
        elif item[2] == 'Comments made':
            commentsmade = item[3]
            # print(commentsmade)
        elif item[2] == 'Assigned to':
            assignedto = item[3]
            # print(assignedto)
        elif item[2] == 'Commented on':
            commentedon = item[3]
            # print(commentedon)
        elif item[2] == 'QA-Contact':
            qacontact = item[3]
            # print(qacontact)
        elif item[2] == 'Patches submitted':
            patchessubmitted = item[3]
            # print(patchessubmitted)
        elif item[2] == 'Patches reviewed':
            patchesreviewed = item[3]
            # print(patchesreviewed)
        elif item[2] == 'Bugs poked':
            bugspoked = item[3]
            # print(bugspoked)
    rows.append([userid, permissions, reviewrequests, feedbackrequests, needinforequests,
                 bugsfiled, commentsmade, assignedto, commentedon, qacontact, patchessubmitted, patchesreviewed,
                 bugspoked])
    # print(rows)
    csvFile.close()

    # print(result)
    # 原本是用table数据转成json操作的,但给出的json结构不适合读取
    # doc = tb.to_json(orient='records')  # 表格转存为json数据
    # print(doc)
    # doc = json.loads(doc)
    # print(doc)
    # da = []
    # jobs = doc['data']
    # print(jobs)
    # dic = {}
    # # 从根节点开始，匹配content节点
    # dic['permissions'] = jsonpath.jsonpath(jobs, expr='$..3')
    # dic['Bugs filed'] = jsonpath.jsonpath(jobs, expr='$..12')
    # dic['Comments made'] = jsonpath.jsonpath(jobs, expr='$..13')
    # dic['Assigned to'] = jsonpath.jsonpath(jobs, expr='$..14')
    # dic['Commented on'] = jsonpath.jsonpath(jobs, expr='$..15')
    # dic['QA-Contact'] = jsonpath.jsonpath(jobs, expr='$..16')
    # dic['Patches submitted'] = jsonpath.jsonpath(jobs, expr='$..15')
    # dic['Patches submitted'] = jsonpath.jsonpath(jobs, expr='$..16')


if __name__ == '__main__':
    try:
        # db = pymysql.connect(host="127.0.0.1", port=3306, user="root", passwd="shige.", db="xu", charset="utf8mb4")
        # cursor = db.cursor()
        headers = {
            'cookie':
            'lastCity=101010100; JSESSIONID=""; __g=-; _uab_collina=155269833969139683439973; __c=1552698410; '
            '__l=r=https%3A%2F%2Fwww.zhipin.com%2F&l=%2Fwww.zhipin.com%2Fjob_detail%2F%3Fquery%3D%25E5%25A4%25A7'
            '%25E6%2595%25B0%25E6 '
            '%258D%25AE%26city%3D101010100%26industry%3D%26position%3D; '
            'Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1552698340, '
            '1552698711; __a=34449685.1552698337.1552698337.1552698410.7.2.6.7; '
            'Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1552698721',
            'accept-encoding':
            'gzip, deflate, br',
            'accept-language':
            'zh-CN,zh;q=0.9',
            'user-agent':
            'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 '
            'Safari/537.36',
            'accept':
            'application/json, text/javascript, */*; q=0.01',
            'referedr':
            'https://www.zhipin.com/job_detail/?query=%E5%A4%A7%E6%95%B0%E6%8D%AE&city=101010100&industry=&position=',
            'authority':
            'www.zhipin.com',
            'x-requested-with':
            'XMLHttpRequest',
        }
        for i in range(0, 1):
            sf = sourcefile+str(i)+'.txt'
            tf = targetfile+str(i)+'.csv'
            j = 0
            for userid in open(sf):
                result = []
                id = userid[:-1]
                # id = '120380'
                url = 'https://bugzilla.mozilla.org/user_profile?user_id=' + id
                j += 1
                print('正在处理第'+str(j)+'条记录!')
                d = getProfile(url, id)
                # d = getUserPorfile(url)
            cs = pd.DataFrame(rows)
            cs.to_csv(tf, mode='a', header=False,
                      encoding='utf8', index=False)

    except Exception as e:
        print(e)
